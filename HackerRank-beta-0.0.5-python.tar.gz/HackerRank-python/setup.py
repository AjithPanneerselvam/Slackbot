from setuptools import setup, find_packages

setup(
    name="HackerRank",
    version="0.0.5",
    description="Python SDK for HackerRank",
    author="RESTUnited",
    author_email="feedback@restunited.com",
    url="https://restunited.com/releases/437757031778092884/wrappers",
    packages=find_packages(),
    license="Apache License 2.0",
)
